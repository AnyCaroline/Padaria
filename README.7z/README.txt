

------------------------LINK NO GIT-------------------------

            https://github.com/AnyCaroline/Padaria.git




Criado as pastas - Imagens e Video
Adicionado imagens 

Criado logo da padaria
Feito Listas de protudos;
Tabelas com dias e horários de funcionamento;
Tabela de cardápio;
Adição de imagens para exibir produtos e ambiente da padaria;
Video para mostrar mais sobre o comercio.